<?php
// Autoload
use PHPUnit\Framework\TestCase;
/**
* NothingTest
*/
class NothingTest extends TestCase {
  
  public function testNothing()
  {
  }
}