<?php

use PHPUnit\Framework\TestCase;
use TinyLara\TinyRouter\TinyRouter as Route;
/**
* RoutingTest
* to be filled up...
*/
class RoutingTest extends TestCase {

  public function testGet()
  {
    $this->assertEquals('get', 'get');
  }
}