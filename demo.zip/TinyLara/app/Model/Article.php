<?php

namespace App\Model;

/**
* Article Model
*/
class Article extends Illuminate\Database\Eloquent\Model {
  public $timestamps = false;
}