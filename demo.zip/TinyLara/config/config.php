<?php

return [
  'base_url' => 'http://localhost:8080/TinyLara/public/',
  'time_zone' => 'UTC', // China use 'Asia/Shanghai'
  'aliases' => [
    'Log' => TinyLara\Support\Facades\Log::class,
  ],
];