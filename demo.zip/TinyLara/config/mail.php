<?php

return [
  'host' => 'smtp.163.com',
  'username' => 'ooxx@163.com',
  'password' => 'password',
  'secure' => ''
];