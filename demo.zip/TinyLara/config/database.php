<?php

return [
  'driver'    => 'mysql',
  'host'      => '127.0.0.1',
  'database'  => 'mydb',
  'username'  => 'root',
  'password'  => 'LLawliet',
  'charset'   => 'utf8',
  'collation' => 'utf8_general_ci',
  'prefix'    => ''
  ];